package io.spring.security.login.iospringsecurity;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Controller;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LoginController {
 
	@GetMapping("/login")
	public String login() {
		
		return "login.html";
	}
	
	@GetMapping("/welcome")
	public void welcome(HttpServletResponse response) throws IOException {
	    response.setContentType("application/pdf");
	    StreamUtils.copy(new FileSystemResource("C:/Users/ankit kumar/Desktop/AnkitResume.pdf").getInputStream(), response.getOutputStream());
	    response.flushBuffer();
	}
	
	@GetMapping("/logout")
	public String logout() {
		
		return "logout.html";
	}
	
}
